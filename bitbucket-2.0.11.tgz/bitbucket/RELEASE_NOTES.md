* Update Helm chart version
